# ASX Portfolio Intelligence System — Example Output

## Document Purpose
This document provides a complete example of the daily portfolio report output. Use this as the reference for report formatting and content structure.

---

## Complete Email Report Example

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                     SMSF PORTFOLIO INTELLIGENCE REPORT
                         Thursday, 2 January 2025
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PORTFOLIO SNAPSHOT
──────────────────────────────────────────────────────────────────────────────
  Total Value:     $368,542          Cost Basis:    $312,500
  Unrealised P&L:  +$56,042 (+17.9%)
  
  vs XJO (YTD):    +5.2% outperformance
  vs XSO (YTD):    +3.1% outperformance

  Holdings: 21 │ SMSF: 18 │ Trader: 3

MARKET CONTEXT
──────────────────────────────────────────────────────────────────────────────
  XJO:  8,245 │ Above 50 EMA (8,180) │ Above 200 EMA (7,950)
  Regime: RISK-ON │ Breadth: 62% above 200 EMA
  
  RBA: Rates steady at 4.35% │ Next meeting: 4 Feb
  AUD/USD: 0.6245 (-0.3% WoW)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                              ACTION REQUIRED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔴 URGENT: REDUCE POSITION
──────────────────────────────────────────────────────────────────────────────

PNC │ Pioneer Credit Limited │ REDUCE 50%
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Position:    28,772 units @ $0.684 avg
Current:     $0.695 │ P&L: +$316 (+1.6%)
Weight:      5.4% of portfolio

┌─────────────────────────────────────────────────────────────────────────────┐
│ TECHNICAL ASSESSMENT                                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  PBAS Score:        0.31 (was 0.52 three months ago)                       │
│  Interpretation:    OVERPRICED — price ahead of business fundamentals      │
│                                                                             │
│  Computation:                                                               │
│    Business Momentum: -0.08 (negative due to OCF decline)                  │
│    Price Momentum:    +0.05 (stock up 5% in 12 months)                     │
│    Divergence:        -0.13 (business lagging price)                       │
│                                                                             │
│  VLI Score:         -0.42 (DISTRIBUTING)                                   │
│    Vol Z-score:       +1.2 (elevated volume)                               │
│    Price vs VWAP:     0.97 (below, on volume = distribution)               │
│                                                                             │
│  Regime:            DECAY (confidence: 0.68)                               │
│    Below 20 EMA ($0.72), Below 50 EMA ($0.74)                              │
│    Failed breakout at $0.78 on 12-Dec with 2.1x volume                     │
│                                                                             │
│  Cooked Score:      2 of 5 triggers (FLAGGED)                              │
│    ✗ PBAS < 0.35                                                           │
│    ✗ OCF declining while debt stable                                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ FUNDAMENTAL ASSESSMENT                                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Cash Conversion:   DETERIORATING                                          │
│    OCF/EBITDA:      0.58 (was 0.82 in FY23) — below 0.70 threshold        │
│    FCF Margin:      2.1% (was 5.8%)                                        │
│                                                                             │
│  Collections Rate:  DECLINING                                              │
│    Per 4C (Oct):    Collections down 8% QoQ                                │
│    PDL purchases:   Flat, not replacing runoff                             │
│                                                                             │
│  Balance Sheet:     STABLE (not the issue)                                 │
│    Net Debt/EBITDA: 1.8x                                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ ANNOUNCEMENT ANALYSIS (Last 30 Days)                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Total: 3 │ High-Signal: 1 │ Noise: 2                                      │
│                                                                             │
│  18-Dec │ Appendix 4C Quarterly │ SNI: 0.62 │ HIGH-SIGNAL                  │
│    Summary: Net operating cash inflow $2.1M (down from $3.8M prior Q).     │
│             Collections $18.2M vs $19.8M.                                  │
│    Reaction: -3.2% on T+1, held at -2.8% by T+3. Volume 1.8x average.     │
│    Signal: NEGATIVE — cash generation weakening                            │
│                                                                             │
│  10-Dec │ AGM Chairman Address │ SNI: 0.08 │ NOISE                         │
│  02-Dec │ Change of Company Secretary │ SNI: 0.02 │ NOISE                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ DECISION                                                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ACTION:        REDUCE by 50% (sell ~14,400 units)                         │
│  CONFIDENCE:    HIGH                                                        │
│  URGENCY:       This week                                                   │
│                                                                             │
│  EVIDENCE SUPPORTING ACTION:                                                │
│    1. PBAS collapsed from 0.52 to 0.31 over 3 months (below 0.35 threshold)│
│    2. OCF/EBITDA ratio fell from 0.82 to 0.58 (below 0.70 minimum)         │
│    3. VLI = -0.42 indicates institutional distribution, not accumulation  │
│                                                                             │
│  RISK IF NO ACTION:                                                         │
│    Next 4C (late Jan) likely to show continued deterioration               │
│    Support at $0.62 (200 EMA); breach = -11% downside                      │
│                                                                             │
│  EXECUTION:                                                                 │
│    Sell at market on open                                                  │
│    If $0.68 not achievable, limit at $0.67                                │
│    Retain 14,400 units; reassess after Jan 4C                             │
│                                                                             │
│  STOP-LOSS (Remaining Position):                                            │
│    Hard stop: $0.58 (-16% from current)                                    │
│    Thesis broken: Collections decline >15% in next 4C                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ JUSTIFIED GAIN ANALYSIS                                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Your 12-month return:      +5.2%                                          │
│  Justified return (PBAS):   -8.0% (business momentum negative)             │
│  Divergence:                +13.2% (you're AHEAD of fundamentals)          │
│                                                                             │
│  Interpretation: Current price not supported by business performance.      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘


🟡 WATCH CLOSELY
──────────────────────────────────────────────────────────────────────────────

ACDC │ ETFS Battery Tech & Lithium ETF │ WATCH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Position:    141 units @ $141.00 avg
Current:     $136.20 │ P&L: -$677 (-3.4%)
Weight:      5.2% of portfolio

┌─────────────────────────────────────────────────────────────────────────────┐
│ TECHNICAL ASSESSMENT                                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Regime:            DISTRIBUTION (confidence: 0.62)                        │
│    Price at 200 EMA ($135.80) — critical support                           │
│    Below 20 EMA ($139.40) and 50 EMA ($141.20)                             │
│                                                                             │
│  VLI Score:         -0.35 (leaning DISTRIBUTING)                           │
│    Volume elevated on down days                                            │
│                                                                             │
│  Relative Strength: WEAKENING                                              │
│    vs XJO 3-month: 0.92 (underperforming by 8%)                           │
│    RS rank dropped from 65th to 42nd percentile                           │
│                                                                             │
│  Thematic Check:    HEADWINDS                                              │
│    Lithium carbonate spot: -18% in December                                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

  WATCH TRIGGER:  Close below $134.00 (2% below 200 EMA)
  ACTION IF HIT:  Trim 50% of position
  
  HOLD TRIGGER:   Close above $142.00 (reclaim 50 EMA) with volume >1.2x avg
  ACTION IF HIT:  Maintain position, upgrade to HOLD


ASB │ Austal Limited │ WATCH (Positive)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Position:    2,915 units @ $6.819 avg
Current:     $7.85 │ P&L: +$3,005 (+15.1%)
Weight:      6.2% of portfolio

┌─────────────────────────────────────────────────────────────────────────────┐
│ TECHNICAL ASSESSMENT                                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  PBAS Score:        0.69 (UNDERPRICED)                                     │
│    Defence order book growing faster than price                            │
│                                                                             │
│  Regime:            BREAKOUT (confidence: 0.72)                            │
│    New 52-week high on 28-Dec ($7.92)                                      │
│    Volume on breakout: 2.4x average                                        │
│    All EMAs stacked bullish                                                │
│                                                                             │
│  VLI Score:         0.68 (ACCUMULATING)                                    │
│    Institutional buying pattern evident                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

  WATCH REASON:  Half-year results due ~15 Jan
  CATALYST:      US Navy LCS sustainment contract update expected
  
  RISK: Gap up on results = consider trimming 25% into strength
  OPPORTUNITY: Pullback to $7.20-$7.40 (20 EMA) = add opportunity


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                            HOLDINGS SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

INFRASTRUCTURE BLOCK │ 32.1% of Portfolio │ Target: 30%
──────────────────────────────────────────────────────────────────────────────
┌────────┬─────────┬────────┬───────┬──────────────┬───────────┬────────────┐
│ Ticker │ Current │ P&L %  │ PBAS  │ Regime       │ VLI       │ Action     │
├────────┼─────────┼────────┼───────┼──────────────┼───────────┼────────────┤
│ APA    │ $9.85   │ +5.7%  │ 0.58  │ range        │ +0.12 neu │ HOLD       │
│ DOW    │ $8.45   │ +5.7%  │ 0.65  │ trend_up     │ +0.38 acc │ HOLD       │
│ GNP    │ $7.10   │ +12.6% │ 0.71  │ trend_up     │ +0.52 acc │ HOLD       │
│ SKS    │ $4.35   │ +8.1%  │ 0.68  │ accumulation │ +0.61 acc │ HOLD       │
│ SRG    │ $3.12   │ +4.0%  │ 0.72  │ trend_up     │ +0.64 acc │ HOLD       │
│ SSM    │ $2.45   │ +8.0%  │ 0.61  │ trend_up     │ +0.35 acc │ HOLD       │
└────────┴─────────┴────────┴───────┴──────────────┴───────────┴────────────┘

Block Assessment:
  Thesis INTACT: Government infrastructure spend pipeline remains strong.
  Recent catalyst: GNP contract win $28M (Dec-18) — SNI 0.74.
  Correlation alert: DOW/SSM/SRG correlation = 0.78 (diversification limited).
  Weight 32.1% approaching 35% cap — defer new adds to this sector.


GROWTH BLOCK │ 27.0% of Portfolio │ Target: 25%
──────────────────────────────────────────────────────────────────────────────
┌────────┬─────────┬────────┬───────┬──────────────┬───────────┬────────────┐
│ Ticker │ Current │ P&L %  │ PBAS  │ Regime       │ VLI       │ Action     │
├────────┼─────────┼────────┼───────┼──────────────┼───────────┼────────────┤
│ ASB    │ $7.85   │ +15.1% │ 0.69  │ breakout     │ +0.68 acc │ WATCH ↑    │
│ CGS    │ $2.55   │ +9.8%  │ 0.55  │ range        │ +0.18 neu │ HOLD       │
│ GDG    │ $6.20   │ +6.3%  │ 0.62  │ trend_up     │ +0.42 acc │ HOLD       │
│ MYG    │ $3.15   │ +6.8%  │ 0.58  │ range        │ +0.08 neu │ HOLD       │
│ PNC    │ $0.695  │ +1.6%  │ 0.31  │ decay        │ -0.42 dis │ 🔴 REDUCE  │
└────────┴─────────┴────────┴───────┴──────────────┴───────────┴────────────┘

Block Assessment:
  PNC deterioration dragging block quality. ASB strength offsetting.
  CGS: Next 4C critical — cash runway monitoring required.


DEFENSIVE BLOCK │ 19.1% of Portfolio │ Target: 20%
──────────────────────────────────────────────────────────────────────────────
┌────────┬─────────┬────────┬──────────────────────────────────┬────────────┐
│ Ticker │ Current │ P&L %  │ Notes                            │ Action     │
├────────┼─────────┼────────┼──────────────────────────────────┼────────────┤
│ AAA    │ $50.35  │ +0.2%  │ Cash proxy, 4.8% yield           │ HOLD       │
│ PMGOLD │ $72.10  │ +7.9%  │ Gold at highs, RSI 68            │ HOLD/WATCH │
│ VACF   │ $51.80  │ +0.3%  │ Bond ETF, duration risk low      │ HOLD       │
└────────┴─────────┴────────┴──────────────────────────────────┴────────────┘

Block Assessment:
  PMGOLD at 13.9% weight — approaching 15% trim threshold.
  If gold RSI >75 on weekly, consider trimming 20%.


THEMATIC ETF BLOCK │ 13.8% of Portfolio
──────────────────────────────────────────────────────────────────────────────
┌────────┬─────────┬────────┬──────────────────────────────────┬────────────┐
│ Ticker │ Current │ P&L %  │ Thematic Status                  │ Action     │
├────────┼─────────┼────────┼──────────────────────────────────┼────────────┤
│ ACDC   │ $136.20 │ -3.4%  │ Lithium weak, at 200 EMA         │ 🟡 WATCH   │
│ NDQ    │ $58.40  │ +3.7%  │ US tech resilient                │ HOLD       │
│ SEMI   │ $24.80  │ +7.3%  │ AI demand strong                 │ HOLD       │
└────────┴─────────┴────────┴──────────────────────────────────┴────────────┘


BLUE CHIP BLOCK │ 5.5% of Portfolio │ Target: 5-10%
──────────────────────────────────────────────────────────────────────────────
┌────────┬─────────┬────────┬───────┬──────────────┬────────────────────────┐
│ Ticker │ Current │ P&L %  │ PBAS  │ Regime       │ Action                 │
├────────┼─────────┼────────┼───────┼──────────────┼────────────────────────┤
│ WES    │ $76.20  │ -6.2%  │ 0.48  │ range        │ HOLD (below avg cost)  │
│ WOW    │ $30.10  │ +2.6%  │ 0.52  │ range        │ HOLD                   │
└────────┴─────────┴────────┴───────┴──────────────┴────────────────────────┘


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                           PORTFOLIO HEALTH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CONCENTRATION CHECK
──────────────────────────────────────────────────────────────────────────────
  ✓ Largest position: ASB at 6.2% (below 8% limit)
  ✓ Top 5 positions: 29.8% (below 40% limit)
  ⚠ Infrastructure sector: 32.1% (approaching 35% limit)
  ✓ No single stock >8%

QUALITY DISTRIBUTION
──────────────────────────────────────────────────────────────────────────────
  PBAS > 0.65 (Underpriced):    6 holdings (29%)
  PBAS 0.50-0.65 (Fair):        11 holdings (52%)
  PBAS < 0.50 (Watch):          4 holdings (19%)

REGIME DISTRIBUTION
──────────────────────────────────────────────────────────────────────────────
  Trend Up / Breakout:          9 holdings (43%)
  Accumulation:                 3 holdings (14%)
  Range:                        6 holdings (29%)
  Distribution / Decay:         3 holdings (14%)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                          UPCOMING CATALYSTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

┌────────────┬────────┬──────────────────────────────┬──────────────────────┐
│ Date       │ Ticker │ Event                        │ Impact / Watch For   │
├────────────┼────────┼──────────────────────────────┼──────────────────────┤
│ ~15 Jan    │ ASB    │ Half-year results            │ US Navy contract $   │
│ ~20 Jan    │ CGS    │ 4C Quarterly                 │ Cash burn rate       │
│ ~28 Jan    │ PNC    │ 4C Quarterly                 │ Collections trend    │
│ ~30 Jan    │ GNP    │ 4C Quarterly                 │ Contract backlog     │
│ 4 Feb      │ ALL    │ RBA Rate Decision            │ Impact on PNC, GDG   │
│ ~15 Feb    │ SRG    │ Half-year results            │ Margin confirmation  │
└────────────┴────────┴──────────────────────────────┴──────────────────────┘


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                              APPENDIX
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SIGNAL DEFINITIONS
──────────────────────────────────────────────────────────────────────────────
  PBAS (Price-Business Alignment Score)
    0.00-0.35: Overpriced — price ahead of fundamentals
    0.35-0.65: Fairly valued
    0.65-1.00: Underpriced — business ahead of price
    
  VLI (Volume Lead Indicator)
    > +0.50: Accumulation (institutional buying)
    -0.30 to +0.30: Neutral
    < -0.30: Distribution (institutional selling)
    
  SNI (Signal-to-Noise Index)
    > 0.60: High-signal announcement
    0.30-0.60: Moderate signal
    < 0.30: Noise
    
  Regime Classifications
    breakout: New highs on volume
    trend_up: Higher highs, bullish EMA stack
    accumulation: Flat price, rising volume
    range: Mean-reverting, no trend
    distribution: Flat highs, weakening volume
    decay: Lower lows, failed rallies

STRATEGY PARAMETERS
──────────────────────────────────────────────────────────────────────────────
  Strategy: SMSF Growth-Quality Hybrid v2.1
  Last updated: 28-Dec-2024
  
  Key thresholds:
    PBAS minimum: 0.45
    OCF/EBITDA minimum: 0.70
    Max single position: 8%
    Max sector: 35%


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Report generated: 2025-01-02 07:15:00 AEDT
Data sources: EODHD, ASX Announcements
Processing time: 847 seconds
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Report Characteristics

### What Makes This Report Good

1. **Every claim has a number**: No generic statements
2. **Technical evidence boxes**: Clear separation of signal types
3. **Actionable decisions**: Specific actions with execution guidance
4. **Evidence trail**: 3 evidence points per decision
5. **Risk quantification**: Stop losses in dollar terms
6. **Catalyst awareness**: Upcoming events listed
7. **Portfolio context**: Sector limits, concentration checks

### Formatting Patterns

| Element | Character |
|---------|-----------|
| Major section divider | `━━━━━━` |
| Minor section divider | `──────` |
| Box top/bottom | `┌──┐` / `└──┘` |
| Box sides | `│` |
| Table corners | `┌┬┐├┼┤└┴┘` |
| Check mark | `✓` |
| Warning | `⚠` |
| Cross | `✗` |

---

## Next Document
Proceed to `12-evidence-chain.md` for the complete evidence mapping specification.
